--- C> start c:/uebungen/cre$alleora.sql
---------------------------
----CONNECT sl01/sl01;   --case sensitive 
CONNECT sl01/sl01@orcl;
DROP TABLE Tvautor;
DROP TABLE Tisbn;
DROP TABLE Tbuch;
DROP TABLE Tverlag;
DROP TABLE Tautor;
 
COMMIT;
-----------------------------------------------
  CREATE TABLE Tverlag
  (
   Verlagnr   NUMBER(38)    NOT NULL
  ,Verlag     CHAR(20)   NOT NULL
  ,PRIMARY KEY (Verlagnr)
  )
  ;
-----------------------------------------------
  CREATE TABLE Tbuch
  (
   Buchnr        NUMBER(38)      NOT NULL
  ,Erschj        NUMBER(4)
  ,Preis         NUMBER(7,2)
  ,Verlagnr      NUMBER(38)
  ,Titel         VARCHAR2(127) NOT NULL
  ,PRIMARY KEY (Buchnr)
  )
  ;
  ALTER TABLE Tbuch ADD CONSTRAINT
                  FK_Tbuch_Tverlag
                  FOREIGN KEY (Verlagnr)
                  REFERENCES Tverlag(Verlagnr)
                  ;
                --ON DELETE NO ACTION
   
  GRANT SELECT ON Tbuch TO PUBLIC
  ;
-----------------------------------------------
  CREATE TABLE Tisbn
  (
   Buchnr    NUMBER(38) NOT NULL
  ,Isbn      CHAR(10)  NOT NULL
  ,Lfdnr     NUMBER(1) NOT NULL
  ,PRIMARY KEY (Isbn)
  ,CONSTRAINT ALTKEY_Tisbn UNIQUE (Buchnr,Lfdnr)
  ,FOREIGN KEY (Buchnr) 
               REFERENCES Tbuch(Buchnr)
               ON DELETE CASCADE
  )
  ;
  GRANT SELECT ON Tisbn  TO PUBLIC
  ;
  -----------------------------------------------
  CREATE TABLE Tautor
  (
   Autornr      NUMBER(38)      NOT NULL
  ,Autor        VARCHAR2(240) NOT NULL
  ,Geburtsdatum DATE
  ,PRIMARY KEY (Autornr)
  )
  ;
  GRANT SELECT ON Tautor TO PUBLIC
  ;
  -----------------------------------------------
  CREATE TABLE Tvautor
  (
   Buchnr    NUMBER(38) NOT NULL
  ,Autornr   NUMBER(38) NOT NULL
  ,Lfdnr     NUMBER(1) NOT NULL
  ,Praemie   NUMBER(9,3)
  ,PRIMARY KEY (Autornr,Buchnr)
  ,CONSTRAINT ALTKEY_Tvautor UNIQUE (Buchnr,lfdnr)
  ,FOREIGN KEY (Buchnr)
               REFERENCES Tbuch (Buchnr)
               ON DELETE CASCADE
  ,FOREIGN KEY (Autornr)
               REFERENCES Tautor (Autornr)
             --ON DELETE NO ACTION
  )
  ;
  GRANT SELECT ON Tvautor TO PUBLIC
  ;
 









