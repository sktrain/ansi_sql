USE sample
GO
delete from tbuch; 
delete from tverlag;
INSERT INTO tverlag(verlagnr, verlag) VALUES
( 1111, 'Forkel');

delete from tbuch;
INSERT INTO tbuch(buchnr,erschj, preis, titel) VALUES
 ( 5, 1988, 3.50, 'Ansichten eines Clowns')
;
INSERT INTO tbuch(buchnr,erschj, preis, titel) VALUES
( 6, 1988, 20.50, 'die Blechtrommel')
;
INSERT INTO tbuch(buchnr,erschj, preis, titel) VALUES
( 7, 1989, 99.99, 'der Name der Rose')
;
INSERT INTO tbuch(buchnr,erschj, preis, titel) VALUES
( 8, 1977, 00.50, 'der Butt')
;
INSERT INTO tbuch(buchnr,erschj, preis, titel) VALUES
( 9, 1990, 55.00, 'DB2 fuer Sie')
;
INSERT INTO tbuch(buchnr,erschj, preis, titel) VALUES
(11, 1990,  NULL, 'Elvis in Heidelberg')
;
INSERT INTO tbuch(buchnr,erschj, preis, titel) VALUES
(12, 1989,  NULL, 'a guide to db2')
;
INSERT INTO tbuch(buchnr,erschj, preis, titel) VALUES
(18, 1989, 99.99, 'Database Systems')
INSERT INTO tbuch(buchnr,erschj, preis, titel) VALUES
(27, Null, 99.99, 'die J�din von Toledo')
;


UPDATE Tbuch set verlagnr = 1111
where tbuch.buchnr = 8
      or tbuch.buchnr = 9;

SELECT * FROM tbuch order by buchnr;

delete FROM TISBN;
INSERT INTO TISBN(BUCHNR,isbn, lfdnr) VALUES
 (08, '3472864303', 01)
;
INSERT INTO TISBN(BUCHNR,isbn, lfdnr) VALUES
(12, '0201501139', 01)
;
INSERT INTO TISBN(BUCHNR,isbn, lfdnr) VALUES
(08, '34728643yx', 02)

--INSERT INTO TISBN(BUCHNR,isbn, lfdnr) VALUES
-- (99, '34899943yx',2)
--;
SELECT * FROM TISBN;

delete FROM tautor;
INSERT INTO tautor(autornr,autor) VALUES
 (1, 'Boell')
;
INSERT INTO tautor(autornr,autor) VALUES
(2, 'Grass')
;
INSERT INTO tautor(autornr,autor) VALUES
(3, 'Eco')
;
INSERT INTO tautor(autornr,autor) VALUES
(6, 'Scheifele')
;
INSERT INTO tautor(autornr,autor) VALUES
(10,'Emil Hack')
;
INSERT INTO tautor(autornr,autor) VALUES
(11, 'Frieda Holz')
;
INSERT INTO tautor(autornr,autor) VALUES
(20,  'C. J. Date')
;
INSERT INTO tautor(autornr,autor) VALUES
(21, 'Colin J. White')
;
SELECT * FROM tautor;

delete FROM tvautor;
INSERT INTO tvautor(buchnr,autornr, lfdnr) VALUES
 (05 , 01, 0)
;
INSERT INTO tvautor(buchnr,autornr, lfdnr) VALUES
(06 , 02, 0)
;
INSERT INTO tvautor(buchnr,autornr, lfdnr) VALUES
(07 , 03, 0)
;
INSERT INTO tvautor(buchnr,autornr, lfdnr) VALUES
(08 , 02, 0)
;
INSERT INTO tvautor(buchnr,autornr, lfdnr) VALUES
(09 , 10, 1)
;
INSERT INTO tvautor(buchnr,autornr, lfdnr) VALUES
(09 , 11, 2)
;
INSERT INTO tvautor(buchnr,autornr, lfdnr) VALUES
(12 , 20, 1)
;
INSERT INTO tvautor(buchnr,autornr, lfdnr) VALUES
(12 , 21, 2)
;

update tvautor set praemie = 20.00
where buchnr = 8 and autornr = 2;
update tvautor set praemie = 10.00
where buchnr = 9 and autornr = 10;
update tvautor set praemie = 498.00
where buchnr = 9 and autornr = 11;
update tvautor set praemie = 30.00
where buchnr = 12 and autornr = 20;

select * from tvautor;


insert into tbuch (buchnr , titel)
values( 1 , 'C');
insert into tbuch (buchnr , titel)
values( 2 , 'C');

insert into tautor (autornr , autor)
values( 100 , 'BUSCH');
insert into tautor (autornr , autor)
values( 200 , 'BUSCH');

insert into tvautor (buchnr, autornr , lfdnr)
values( 1 , 100 , 1);
insert into tvautor (buchnr, autornr , lfdnr)
values( 1 , 200,  2);
insert into tvautor (buchnr, autornr , lfdnr)
values( 2 , 200 , 0);



select * from tverlag;
select * from tbuch order by buchnr;
select * from tisbn order by buchnr, lfdnr;
select * from tautor order by autornr;
select * from tvautor order by buchnr, autornr, lfdnr;

commit;




