--use master
--drop database sample
--go
--create database sample
--go
-----------------------------------------------
USE sample
Go
DROP TABLE Tvautor;
DROP TABLE Tisbn;
DROP TABLE Tbuch;
DROP TABLE Tverlag;
DROP TABLE Tautor;
-----------------------------------------------
  CREATE TABLE Tverlag
  (
   Verlagnr   INTEGER    NOT NULL
  ,Verlag     CHAR(20)   NOT NULL
  ,PRIMARY KEY (Verlagnr)
  )
;
 -----------------------------------------------
  CREATE TABLE Tbuch
  (
   Buchnr        INTEGER      NOT NULL
  ,Erschj        DECIMAL(4)
  ,Preis         DECIMAL(7,2)
  ,Verlagnr      INTEGER
  ,Titel         VARCHAR(127) NOT NULL
  ,PRIMARY KEY (Buchnr)
  )
;
  ALTER TABLE Tbuch ADD CONSTRAINT
                  FK_Tbuch_Tverlag
                  FOREIGN KEY (Verlagnr)
                  REFERENCES Tverlag(Verlagnr)
                  ON DELETE NO ACTION
                  ON UPDATE NO ACTION
;
-----------------------------------------------
  CREATE TABLE Tisbn
  (
   Buchnr    INTEGER NOT NULL
  ,Isbn      CHAR(10)  NOT NULL
  ,Lfdnr     DECIMAL(1) NOT NULL
  ,PRIMARY KEY (Isbn)
  ,CONSTRAINT ALTKEY_Tisbn UNIQUE (Buchnr,Lfdnr)
  ,FOREIGN KEY (Buchnr) 
               REFERENCES Tbuch(Buchnr)
               ON DELETE CASCADE
               ON UPDATE NO ACTION
  )
;
-----------------------------------------------
  CREATE TABLE Tautor
  (
   Autornr      INTEGER      NOT NULL
  ,Autor        VARCHAR(240) NOT NULL
  ,Geburtsdatum DATETIME
  ,PRIMARY KEY (Autornr)
  )
;
-----------------------------------------------
  CREATE TABLE Tvautor
  (
   Buchnr    INTEGER NOT NULL
  ,Autornr   INTEGER NOT NULL
  ,Lfdnr     DECIMAL(1) NOT NULL
  ,Praemie   DECIMAL(9,3)
  ,PRIMARY KEY (Autornr,Buchnr)
  ,CONSTRAINT ALTKEY_Tvautor UNIQUE (Buchnr,lfdnr)
  ,FOREIGN KEY (Buchnr)
               REFERENCES Tbuch (Buchnr)
               ON DELETE CASCADE
               ON UPDATE NO ACTION
  ,FOREIGN KEY (Autornr)
               REFERENCES Tautor (Autornr)
               ON DELETE NO ACTION
               ON UPDATE NO ACTION
  )
;
-----------------------------------------------